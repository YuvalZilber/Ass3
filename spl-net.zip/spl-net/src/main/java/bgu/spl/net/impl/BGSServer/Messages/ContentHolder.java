package bgu.spl.net.impl.BGSServer.Messages;

public interface ContentHolder {
    public String getContent();
}
