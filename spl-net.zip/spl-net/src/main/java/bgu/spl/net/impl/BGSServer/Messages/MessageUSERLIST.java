package bgu.spl.net.impl.BGSServer.Messages;

import bgu.spl.net.impl.BGSServer.Message;

public class MessageUSERLIST extends Message {
    public MessageUSERLIST() {
        super((short) 7);
    }
}
