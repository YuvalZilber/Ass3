//
// Created by shvatm on 12/31/18.
//

#ifndef BOOST_ECHO_CLIENT_CLIENT_H
#define BOOST_ECHO_CLIENT_CLIENT_H


class Client {

};


#endif //BOOST_ECHO_CLIENT_CLIENT_H
